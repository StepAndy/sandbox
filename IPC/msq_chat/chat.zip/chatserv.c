#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define FPATH "/home/andrew/chat.txt"
#define SERVICE_PORT 100
#define ASSIGNMENT_PORT 101

struct client_info {
	long service_port;
	char nickname[25];
} their;

struct client_dispatcher
{
	long service_port;
	long dispatch_port;
} assign;

int main(int argc, char const *argv[])
{
	int 	chat_id;
	key_t 	chat_key;
	long 	cli_index = 0L;

	chat_key = ftok(FPATH,'A');
	chat_id = msgget(chat_key, IPC_CREAT | 0666);

	msgrcv(chat_id, &their, sizeof(their) - sizeof(long), SERVICE_PORT, 0); //IPC_NOWAIT
	cli_index++;
	assign.service_port = ASSIGNMENT_PORT;
	assign.dispatch_port = cli_index; 
	printf("[%s connected]\n", their.nickname); //не printf, a msgsnd всем

	msgsnd(chat_id, &assign, sizeof(assign) - sizeof(long), 0);

	msgctl(chat_id, IPC_RMID, 0);
	return 0;
}