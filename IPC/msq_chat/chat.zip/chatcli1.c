#include <stdio.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define FPATH "/home/andrew/chat.txt"
#define SERVICE_PORT 100
#define ASSIGNMENT_PORT 101

struct client_info {
	long service_port;
	char nickname[25];
} send_my_info;

struct client_dispatcher
{
	long type; // do not use, only for recieving
	long dispatch_port;
} get_my;

struct client_text_msg {
	long type;
	char text[255];
} msg;

int main(int argc, char const *argv[])
{
	int chat_id;
	key_t chat_key;

	printf("Введите свой ник\n");
	scanf("%s", send_my_info.nickname);
	send_my_info.service_port = SERVICE_PORT;

	chat_key = ftok(FPATH,'A');
	chat_id = msgget(chat_key, IPC_CREAT | 0);

	msgsnd(chat_id, &send_my_info, sizeof(send_my_info) - sizeof(long), 0); //заблокироваться, пока сервер не ответит
	printf("type = %ld\n", send_my_info.service_port );
	msgrcv(chat_id, &get_my, sizeof(get_my) - sizeof(long),
		ASSIGNMENT_PORT, 0); //Получить ответ с новым типом
	printf("new type = %ld\n", get_my.dispatch_port );

	//Теперь можно слать в чат по новому личному порту, откуда будет ...нет
	//Теперь слать в чат общий, откуда будет забираться последовательно сервером и дублироваться всем, а все будут забирать уже 
	//по своим портам в msgrcv 

	return 0;
}